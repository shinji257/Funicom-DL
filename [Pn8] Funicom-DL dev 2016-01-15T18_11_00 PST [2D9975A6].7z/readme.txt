this is a lazy ini




first make sure python 2.7 is installed

for ini instrutions see ini
for que instrutions see que

add urls to the que then run the bat
