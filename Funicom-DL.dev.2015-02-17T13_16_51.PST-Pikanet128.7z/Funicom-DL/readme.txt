this is a lazy ini




first make sure python 2.7 is installed

for ini instrutions see ini
for que instrutions see que

add urls to the que then run the bat








Funicom-DL Pre 4.0 Dev Change Log:


Funicom-DL.dev.2015-02-17T13_16_51.PST-Pikanet128
	Added User and Pika Tag Exceptions
	User is for you to edit if you want
	Pika is for me to release with ones I find
	if you dont want then delete them
	fixed Movie Suport
	Added Extras Suport (No Perfect)
	Added -Q or --quit for the que gets its own line it quits the program early
	changed -g to -G or --global
	set default for -G to -l e -fb ((-q best) implyed)
	py file is compiled
	you can change *.pyni to *.py.ini if you want

Funicom-DL.dev.2014-11-22T21_08_00.PST-Pikanet128
	fixed a stupid major bug

Funicom-DL.dev.2014-11-22T20_36_00.PST-Pikanet128
	fixed unicode title chrashes
	turned echo off
	added debug options
	added -fs
	moved the dl def into a def

Funicom-DL.dev.2014-11-17T23_48_00.PST-Pikanet128
	fixed crashing issue do to site changes

Funicom-DL.dev.2014-10-29T08_25_00.PST-Pikanet128
	fixed the problem with highschool dxd 13 and 14 and for any future simalar problems
	fixed the problem when no -g was used it crashed

Funicom-DL.dev.2014-10-20T11_43_00.PST-Pikanet128
	I think i fixed the problem with ##.# episodes

Funicom-DL.dev.2014-10-19T10_03_00.PST-Pikanet128
	added -g option
	made -q best default
	added readme
	added changelog

Funicom-DL.dev.2014-10-01T09_55_00.PST-Pikanet128
	First Ver
